// JavaScript Document
myFocus.set({
	id:'banner',//ID 
	pattern:'mF_liquid' //mF_liquid mF_liuzg /
});
$(document).ready(function(){
	$(".nav ul li,.mm").hover(
		function(){
			if($(this).children(".son")){
				$(this).children(".son").show(100);
			}
			
		},
		function(){
			$(this).children(".son").hide(50);
			
		}
	);
	});	
		
		window._bd_share_config = {
		share : [{
			"bdSize" : 16
		}],
		slide : [{	   
			bdImg : 1,
			bdPos : "left",
			bdTop :200
		}]
	}
	with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];
	
function setTab(name,cursel,n){
		for(i=1;i<=n;i++){
				var menu=document.getElementById(name+i);
				var con=document.getElementById("con_"+name+"_"+i);
				menu.className=i==cursel?"hover":"";
				con.style.display=i==cursel?"block":"none";
			}
	 }
	
 function checkForm(){
if(myform.cont.value==""){
	
	myform.cont.focus();
	return false;
	}
if(myform.name.value==""){
	
	myform.name.focus();
	return false;
	}

if(myform.phone.value==""){
	
	myform.phone.focus();
	return false;
	}
}