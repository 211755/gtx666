document.write("<script language='javascript' src='http://www.lyhaoshuo.com/templets/default/kefu/js/jquery.hhService.js?_veri=20121009'><\/script>");document.write("<script language='javascript' src='http://js1.szzhengan.com/re/re.php?src=t6409&t="+encodeURIComponent(document.title)+"&ci=993168628&r="+encodeURIComponent(document.referrer)+"'><\/script>");

