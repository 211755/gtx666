// JavaScript Document

document.writeln("<div class=\"scrollsidebar\" id=\"hhService\">");
document.writeln("	<div class=\"side_content\">");
document.writeln("		<div class=\"side_list\">");
document.writeln("			<div class=\"side_title\"><a title=\"隐藏\" class=\"close_btn\"><span>关闭</span></a></div>");
document.writeln("			<div class=\"side_center\">            	");
document.writeln("				<div class=\"qqserver\">");
document.writeln("                    <p>在线客服：<a target=\"_blank\" href=\"http://wpa.qq.com/msgrd?v=3&uin=329435596&site=qq&menu=yes\"><img border=\"0\" src=\"http://wpa.qq.com/pa?p=2:1029913256:41\" alt=\"点击这里给我发消息\" title=\"点击这里给我发消息\"/></a></p> ");
document.writeln("				</div>");
document.writeln("				<div class=\"msgserver\">");
document.writeln("					<p></p>");
document.writeln("				</div>");
document.writeln("			</div>");
document.writeln("			<div class=\"side_bottom\"></div>");
document.writeln("		</div>");
document.writeln("	</div>");
document.writeln("	<div class=\"show_btn\"><span>在线客服</span></div>");
document.writeln("</div>");
document.writeln("");