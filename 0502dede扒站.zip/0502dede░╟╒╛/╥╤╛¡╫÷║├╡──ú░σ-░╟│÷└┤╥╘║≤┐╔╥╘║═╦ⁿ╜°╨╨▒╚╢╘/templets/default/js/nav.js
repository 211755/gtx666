﻿ (function(){
	//导航选中
	var url = location.pathname, navg = $('.nav ul li');
	if(url == '/' || url == '/index.html'){
		navg.eq(0).addClass('current');
	}else if(!url.indexOf('/guanyuwomen')){
		navg.eq(1).addClass('current');
	}else if(!url.indexOf('/new/')){
		navg.eq(2).addClass('current');
	}else if(!url.indexOf('/pro/')){
		navg.eq(3).addClass('current');
	}else if(!url.indexOf('/case/')){
		navg.eq(4).addClass('current');
	}else if(!url.indexOf('/ser')){
		navg.eq(5).addClass('current');
	}else if(!url.indexOf('/net/')){
		navg.eq(6).addClass('current');
	}else if(!url.indexOf('/rencai/')){
		navg.eq(7).addClass('current');
	}else if(!url.indexOf('/lianxiwomen')){
		navg.eq(8).addClass('current');
	}else if(!url.indexOf('/tongdao/')){
		navg.eq(9).addClass('current');
	}
})()