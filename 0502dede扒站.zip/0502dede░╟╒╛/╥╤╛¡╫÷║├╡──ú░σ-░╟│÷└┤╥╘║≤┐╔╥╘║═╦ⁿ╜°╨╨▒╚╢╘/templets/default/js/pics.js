

var speed=55;
var tab=document.getElementById("demo");
var tab1=document.getElementById("demo1");
var tab2=document.getElementById("demo2");
tab2.innerHTML=tab1.innerHTML;
function Marquee(){
if(tab2.offsetWidth-tab.scrollLeft<=0)
tab.scrollLeft-=tab1.offsetWidth
else{
tab.scrollLeft++;
}
}
var MyMar=setInterval(Marquee,speed);
tab.onmouseover=function() {clearInterval(MyMar)};
tab.onmouseout=function() {MyMar=setInterval(Marquee,speed)};


var speed1=55;
var t=document.getElementById("d");
var t1=document.getElementById("d1");
var t2=document.getElementById("d2");
t2.innerHTML=t1.innerHTML;
function Marquee1(){
if(t2.offsetWidth-t.scrollLeft<=0)
t.scrollLeft-=t1.offsetWidth
else{
t.scrollLeft++;
}
}
var MyMar1=setInterval(Marquee1,speed1);
t.onmouseover=function() {clearInterval(MyMar1)};
t.onmouseout=function() {MyMar1=setInterval(Marquee1,speed1)};